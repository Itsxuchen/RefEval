from types import SimpleNamespace

import numpy as np
import pytest

from src import wmt_blind_crossover as study
from src import wmt_blind_inputs as inputs


def test_document_holdout_and_exceptional_errors():
    docs = {str(i): i+1 for i in range(11)}
    parts = study.split(docs)
    assert len(parts["development"]) == 4
    assert set(parts["development"]).isdisjoint(parts["held"])
    assert study.split(dict(reversed(list(docs.items())))) == parts
    assert inputs._pass_vector([("Accuracy/Omission","Major"),("Source error","Major"),
                                ("Style","Minor"),("Non-translation","Major")]) == (False,True,True,False)


def test_early_and_eventual_compare_the_same_cases():
    # J rejects both. Each early path clears its single predicted failure.
    j=np.array([[False,True,True,True]]*2)
    e=np.array([[[True,False,True,True],[True,True,True,True],[True,False,True,True]],
                [[True,True,True,True]]*3])
    masks=np.array([[[True,False,False,False]]*2])
    counts=study.unit_counts(j,e,masks)
    r=study.measures({k:v.sum() for k,v in counts.items()})
    assert r["early_per100"]==100
    assert r["withdrawn_per100"]==pytest.approx(100/3)
    assert r["same_early_minus_eventual_1to1_per100"]==pytest.approx(0)
    assert r["same_early_minus_eventual_3to1_per100"]==pytest.approx(100/3)
    assert r["early_endorsement_pct"]==pytest.approx(200/3)
    rr=[SimpleNamespace(doc="d1"),SimpleNamespace(doc="d2")]
    assert study.event_support(rr,j,e,masks)["up"]["outputs"]==2


def test_missing_direction_is_undefined_and_fixed_budget():
    j=np.ones((7,4),bool)
    h=np.ones((7,3,4),bool)
    m=study.paths(j,~j)
    assert m.shape==(31,7,4) and (m.sum(axis=(1,2))==14).all()
    counts=study.unit_counts(j,h,m)
    r=study.measures({k:v.sum() for k,v in counts.items()})
    assert np.isnan(r["down_endorsement_pct"])
    assert r["full_minus_retain_1to1_per100"]==0
